# Za moju Žutu 💛 (GitHub Pages)

Ovo je statična web stranica (HTML/CSS/JS) koja se hosta na GitHub Pages.

## 1) Gdje idu slike
Stavi slike u folder:

`assets/photos/`

Preporuka imenovanja:
- Njene slike (više njih): `her-01.jpg`, `her-02.jpg`, `her-03.jpg` ...
- Vaše slike (manje): `us-01.jpg`, `us-02.jpg`, ...

Ako dodaš više slika, samo ih dodaj i u `content.json` u:
- `gallery.herPhotos`
- `gallery.ourPhotos`

## 2) Kako urediti tekst
Sve se uređuje u `content.json`:
- naslov, hero rečenica
- nadimci
- love letter (paragrafi)
- timeline
- razlozi

Ne moraš dirati HTML.

## 3) Pokretanje lokalno
Samo otvori `index.html` u browseru.

Ako ti browser blokira `fetch(content.json)` kada otvaraš file direktno (nekad se desi), pokreni mali lokalni server:
- Windows (PowerShell):
  `python -m http.server 8000`
Pa otvori:
- `http://localhost:8000`

## 4) GitHub Pages deploy
1. Napravi repo na GitHubu (npr. `zuta`).
2. Uploaduj sve fajlove i foldere.
3. GitHub → Repo → Settings → Pages
4. Source: Deploy from a branch
5. Branch: `main` i folder: `/ (root)`
6. Sačekaj da se pojavi link (biće tipa `https://USERNAME.github.io/REPO/`)

## 5) Tip
Ako želiš privatnije, nemoj stavljati previše ličnih informacija u timeline.
